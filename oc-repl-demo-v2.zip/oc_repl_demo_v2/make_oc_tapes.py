#!/usr/bin/env python3
"""Generate VHS .tape files driving the *new* oc-repl tool.

Six demos: 3 TB tasks × 2 protocols (terminus-json, openai-tools).

Each tape:
 1. Hides setup (cd, clear).
 2. Types ``oc-repl --protocol P --sandbox docker:NAME`` and Enter.
 3. Sleeps for the REPL banner / first import work.
 4. Types the task instruction at the ``›`` prompt.
 5. Sleeps long enough for the agent loop to converge.
 6. Types ``/quit`` to end the session.
 7. Final ``Sleep 8s`` static hold.

Conservative fixed Sleeps instead of VHS Wait+Line — proven robust during
the earlier camel/terminus pass; the agent's runtime varies by 2-3× between
turns so generous wallclock is the simplest correct choice.
"""

import pathlib
import textwrap

ROOT = pathlib.Path("/nfs/terminal-rl-workspace/openclaw-repl-demo")
SCEN = ROOT / "scenarios-oc"
OUT = ROOT / "output-oc"

# (task_id, container_short, instruction, agent_sleep_seconds)
TASKS = [
    (
        "hello-world",
        "openclaw-hello",
        "Create /app/hello.txt whose only line is: Hello, world! (with a trailing newline). "
        "Do not create any other files.",
        45,
    ),
    (
        "fix-permissions",
        "openclaw-fixperm",
        "Fix /app/process_data.sh so it can run, then run it once and report the output.",
        60,
    ),
    (
        "recover-obfuscated-files",
        "openclaw-recover",
        "Decode each *.b64_content in /app/sensitive_data/ — basename is base64 of the original "
        "filename, body is base64 of the original content. Restore the files into /app/recovered/.",
        80,
    ),
    (
        "heterogeneous-dates",
        "openclaw-hetdates",
        "Use paste + awk on /app/daily_temp_sf_high.csv and /app/daily_temp_sf_low.csv to compute "
        "the average daily (high - low). Save just the number to /app/avg_temp.txt and cat it.",
        80,
    ),
]

PROTOCOLS = ["terminus-json", "openai-tools"]


def tape_for(protocol: str, task_id: str, container: str, instruction: str, agent_seconds: int) -> str:
    out_base = f"oc-{protocol}-{task_id}"
    # VHS' quoted-string lexer doesn't support \" inside Type "...". The
    # protocols we drive don't need quote characters in the instruction, so we
    # strip any that snuck in.
    instr = instruction.replace('"', "")

    launch = (
        f"oc-repl --protocol {protocol} --sandbox docker:{container}"
    )

    return textwrap.dedent(f"""\
        # oc-repl {protocol} × {task_id}
        Output "{OUT}/{out_base}.gif"
        Output "{OUT}/{out_base}.mp4"
        Set Shell "bash"
        Set FontSize 14
        Set Width 1400
        Set Height 820
        Set Padding 22
        Set Theme "Dracula"
        Set TypingSpeed 45ms

        Hide
        Type "cd /nfs/terminal-rl-workspace" Enter
        Type "clear" Enter
        Show
        Sleep 1500ms

        Type "{launch}" Enter
        Sleep 10s

        Type "{instr}" Enter
        Sleep {agent_seconds}s

        Type "/quit" Enter
        Sleep 8s
        """)


def main() -> None:
    SCEN.mkdir(parents=True, exist_ok=True)
    OUT.mkdir(parents=True, exist_ok=True)
    keep = set()
    for proto in PROTOCOLS:
        for task_id, container, instruction, agent_seconds in TASKS:
            tape = SCEN / f"oc-{proto}-{task_id}.tape"
            tape.write_text(tape_for(proto, task_id, container, instruction, agent_seconds))
            keep.add(tape.name)
    for existing in SCEN.glob("*.tape"):
        if existing.name not in keep:
            existing.unlink()
    print("wrote tapes to", SCEN)
    for p in sorted(SCEN.glob("*.tape")):
        print("  ", p.name)


if __name__ == "__main__":
    main()
