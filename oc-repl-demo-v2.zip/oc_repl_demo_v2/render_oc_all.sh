#!/usr/bin/env bash
# Reset every TB sandbox container then render every oc-repl tape.
# Outputs: openclaw-repl-demo/output-oc/oc-<proto>-<task>.{gif,mp4}

set -euo pipefail
ROOT="/nfs/terminal-rl-workspace/openclaw-repl-demo"
export PATH="${ROOT}/local-bin:${PATH}"
export VHS_NO_SANDBOX=1

declare -A IMAGES=(
    [openclaw-hello]=tb__hello-world__client
    [openclaw-fixperm]=tb__fix-permissions__client
    [openclaw-recover]=tb__recover-obfuscated-files__client
    [openclaw-hetdates]=tb__heterogeneous-dates__client
)

# (tape -> container_to_reset)
declare -A TAPE_CONTAINER=(
    [oc-terminus-json-hello-world.tape]=openclaw-hello
    [oc-terminus-json-fix-permissions.tape]=openclaw-fixperm
    [oc-terminus-json-recover-obfuscated-files.tape]=openclaw-recover
    [oc-terminus-json-heterogeneous-dates.tape]=openclaw-hetdates
    [oc-openai-tools-hello-world.tape]=openclaw-hello
    [oc-openai-tools-fix-permissions.tape]=openclaw-fixperm
    [oc-openai-tools-recover-obfuscated-files.tape]=openclaw-recover
    [oc-openai-tools-heterogeneous-dates.tape]=openclaw-hetdates
)

ORDER=(
    "oc-terminus-json-hello-world.tape"
    "oc-terminus-json-fix-permissions.tape"
    "oc-terminus-json-recover-obfuscated-files.tape"
    "oc-terminus-json-heterogeneous-dates.tape"
    "oc-openai-tools-hello-world.tape"
    "oc-openai-tools-fix-permissions.tape"
    "oc-openai-tools-recover-obfuscated-files.tape"
    "oc-openai-tools-heterogeneous-dates.tape"
)

if [ -n "${ONLY:-}" ]; then
    FILTERED=()
    for t in "${ORDER[@]}"; do
        [[ "$t" == *"${ONLY}"* ]] && FILTERED+=("$t")
    done
    ORDER=("${FILTERED[@]}")
fi

for tape in "${ORDER[@]}"; do
    container="${TAPE_CONTAINER[$tape]}"
    image="${IMAGES[$container]}"
    echo "==> $(date +%H:%M:%S) ${tape}"
    sg docker -c "docker rm -f ${container} 2>/dev/null; sleep 1; docker run -d --name ${container} -w /app ${image} sleep infinity" >/dev/null
    rm -f "${ROOT}/output-oc/${tape%.tape}".{gif,mp4}
    time vhs "${ROOT}/scenarios-oc/${tape}" 2>&1 | tail -3
    ls -la "${ROOT}/output-oc/${tape%.tape}".* 2>/dev/null
done

echo "ALL_DONE_AT_$(date +%H:%M:%S)"
