oc-repl demo v2 — assets
------------------------

What's in this archive
  scenarios-oc/   8 VHS .tape files (terminus-json × 4 tasks + openai-tools × 4 tasks)
  output-oc/      8 .gif + 8 .mp4 — final demo videos
  make_oc_tapes.py    generator: tape configs (instructions, sleep budgets)
  render_oc_all.sh    driver: resets sandbox containers + invokes vhs per tape

Reproducing the recordings
  1. Bring up sglang serving qwen3-8b-rl-iter215 on http://127.0.0.1:30000/v1
     (see issue body §4 step 1)
  2. Install oc-repl:   pip install git+https://github.com/HansBug/oc-repl
  3. Pre-create the 4 sandbox containers (issue body §4 step 2)
  4. Drop these files into /nfs/terminal-rl-workspace/openclaw-repl-demo/
     (or change ROOT in make_oc_tapes.py / render_oc_all.sh accordingly)
  5. python make_oc_tapes.py     # regenerates the .tape files from spec
  6. bash render_oc_all.sh       # renders all 8 demos sequentially

Issue reference: https://github.com/HansBug/OpenClaw-RL/issues/13
